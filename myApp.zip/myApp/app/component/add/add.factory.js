/**
 * Created by knoldus on 28/2/16.
 */

/*angular.module('myApp').factory('addFactory',function($http){


        return   $http.post("reactive-app.herokuapp.com/delete?id=3");


    }
);
*/