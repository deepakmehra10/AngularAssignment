/**
 * Created by knoldus on 28/2/16.
 */

angular.module('myApp').controller('addController',function($scope, $http) {

    alert("add controller");





$scope.save=function(){

    $scope.emp={
        "name":$scope.empname,
        "email":$scope.empemail,
        "dob":$scope.empdob,
        "company":$scope.empcompany,

        "id":$scope.empid

    };
console.log(JSON.stringify(($scope.emp)));

    alert(JSON.stringify($scope.emp));

    //alert($scope.emp.id);
    //alert(myTest);
    //alert(JSON.stringify($scope.));
    alert("success");











};

});