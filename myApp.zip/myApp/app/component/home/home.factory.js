/**
 * Created by knoldus on 26/2/16.
 */

angular.module('myApp').factory('homeFactory',function($http){


           return  $http.get("http://reactive-app.herokuapp.com/getAll");


    }
);
