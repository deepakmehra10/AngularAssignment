/**
 * Created by knoldus on 25/2/16.
 */


angular.module('myApp').controller('homeController',function($scope,homeFactory) {
   alert("home controller");
    var x=homeFactory;
    x.then(function(response){

        $scope.employee=response.data;

    });
});






















