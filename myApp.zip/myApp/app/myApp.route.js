/**
 * Created by knoldus on 25/2/16.
 */
/**
 * Created by akshay on 24/2/16.
 */



angular.module('myApp').config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/home');

    $stateProvider
        .state('home', {
            url: '/home',
            templateUrl: 'app/component/home/home.html',
            controller: 'homeController'

        })

    $stateProvider
        .state('add', {
            url: '/add',
            templateUrl: 'app/component/add/add.html',
            controller: 'addController'
        })

});
