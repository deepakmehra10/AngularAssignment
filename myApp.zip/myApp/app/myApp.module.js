/**
 * Created by knoldus on 25/2/16.
 */

angular.module('myApp',['ui.router']);